﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleSavedSearch
{
    class ProgramSampleSavedSearch
    {
        // for login
        private static string DataSource;
        private static string Username;
        private static string PasswordInClearText;  // obviously don't do this in the 'real world'...

        // for PWSearch.CreateSearch()
        private static string SearchName;
        private static bool ReplaceExisting;

        private static string OwnerProject;
        private static string SearchFolder;
        private static bool SearchSubFolders;

        private static string DocumentName;
        private static string FileName;
        private static string Description;
        private static bool OriginalsOnly;

        private static string SearchText;
        private static bool WholePhrase;
        private static bool AnyWord;

        private static bool SearchAttributes;
        private static string EnvironmentName;
        private static string AttributeColumnNames;
        private static string AttributeValues;

        private static string Workflow;
        private static string States;

        private static string UpdatedAfter;
        private static string UpdatedBefore;

        private static string ViewName;

        private static void GetApplicationDefaultProperties()
        {
            // these can be specified on the command line
            // otherwise edit the .config file for your needs
            DataSource = Properties.Settings.Default.DataSource.Trim();
            Username = Properties.Settings.Default.Username.Trim();
            PasswordInClearText = Properties.Settings.Default.PasswordInClearText.Trim();

            // edit the .config file to change these values...
            SearchName = Properties.Settings.Default.SearchName.Trim();
            ReplaceExisting = Properties.Settings.Default.ReplaceExistingSearch;

            OwnerProject = Properties.Settings.Default.OwnerProject.Trim();
            SearchFolder = Properties.Settings.Default.SearchFolder.Trim();
            SearchSubFolders = Properties.Settings.Default.SearchSubFolders;

            DocumentName = Properties.Settings.Default.DocumentName.Trim();
            FileName = Properties.Settings.Default.FileName.Trim();
            Description = Properties.Settings.Default.Description.Trim();
            OriginalsOnly = Properties.Settings.Default.OriginalsOnly;

            SearchText = Properties.Settings.Default.SearchText.Trim();
            WholePhrase = Properties.Settings.Default.WholePhrase;
            AnyWord = Properties.Settings.Default.AnyWord;

            SearchAttributes = Properties.Settings.Default.SearchAttributes;
            EnvironmentName = Properties.Settings.Default.EnvironmentName.Trim();
            AttributeColumnNames = Properties.Settings.Default.AttributeColumnNames.Trim();
            AttributeValues = Properties.Settings.Default.AttributeValues.Trim();

            Workflow = Properties.Settings.Default.Workflow.Trim();
            States = Properties.Settings.Default.States.Trim();

            UpdatedBefore = Properties.Settings.Default.UpdatedBefore.Trim();
            UpdatedAfter = Properties.Settings.Default.UpdatedAfter.Trim();

            ViewName = Properties.Settings.Default.ViewName.Trim();
        }

        private static void GetUserSpecifiedValuesFromCommandLine(string[] args)
        {
            // sample only implements these arguments...
            bool ShowUsageMessage = false;

            for (var argIndex = 0; argIndex < args.Length; argIndex++)
                if (args[argIndex].ToLower() == "-d")
                {
                    DataSource = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-u")
                {
                    Username = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-p")
                {
                    PasswordInClearText = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-?")
                {
                    ShowUsageMessage = true;
                }
                else
                {
                    ShowUsageMessage = true;
                    Console.WriteLine("[Error  ] Invalid command line argument '{0}'", args[argIndex]);
                }

            if (ShowUsageMessage)
                ShowUsageAndExit();
        }

        public static void ShowPWError()
        {
            Console.WriteLine("[{0}]\n{1}\n{2}",
                    PWWrapper.aaApi_GetLastErrorId(),
                    PWWrapper.aaApi_GetLastErrorMessage(),
                    PWWrapper.aaApi_GetLastErrorDetail());
        }

        public static void ShowUsageAndExit()
        {
            Console.WriteLine("");
            Console.WriteLine("======");
            Console.WriteLine("Usage:");
            Console.WriteLine("======");
            Console.WriteLine("{0} [-d Server:Datasource] [-u Username] [-p Password]", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("------");
            Console.WriteLine("Notes:");
            Console.WriteLine("------");
            Console.WriteLine("Command line arguments override the values in {0}.config.", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("");

            ExitApp(-1);
        }

        public static void ExitApp(int ExitCode)
        {
            // When in the debugger, the console window will stay open.
            if (Debugger.IsAttached)
            {
                Console.Write("Press any key to exit console window when in debug mode...");
                Console.ReadKey();
            }

            Environment.Exit(ExitCode);
        }


        static void Main(string[] args)
        {
            GetApplicationDefaultProperties();

            GetUserSpecifiedValuesFromCommandLine(args);

            // Initialize the PW APIs
            PWWrapper.aaApi_Initialize(0);

            // Before we login, we can check to see what version of ProjectWise are we using.
            // This will be the version of ProjectWise Explorer on this machine.
            Int32 MajorHigh = 0;
            Int32 MajorLow = 0;
            Int32 MinorVersion = 0;
            Int32 BuildNo = 0;

            if (!PWWrapper.aaApi_GetAPIVersion(ref MajorHigh, ref MajorLow, ref MinorVersion, ref BuildNo))
            {
                // In general, it is a good practice to check if a method worked or not
                ShowPWError();
                PWWrapper.aaApi_Uninitialize(); // good practice
                ExitApp(-2);                    // arbitrary exit code
            }
            else
            {
                // You may want to verify the version or log it for debugging purposes...
                Console.WriteLine($"ProjectWise Explorer Version {MajorHigh}.{MajorLow}.{MinorVersion}.{BuildNo}");
            }

            ////////////////////////////////////////////////////////////////////////////////////////
            // sign into our datasource
            // In the real world, you would want to hide the password or use SSO, etc.
            // We are going to cheat and hard-code the password for this sample...
            try
            {
                Console.WriteLine($"Attempting to login to Datasource '{DataSource}' with Username '{Username}'...");

                using (PWSession myPWSession = new PWSession(DataSource, Username, PasswordInClearText))
                {
                    Console.WriteLine("Login OK.");

                    ////////////////////////////////////////////////////////////////////////////////////////
                    // We are going to use the method PWSearch.CreateSearch() to create our saved search.
                    // This method has over 20 parameters of various data types, some of which you may have 
                    // to look up the required values. For example, you know the path to a folder, but you
                    // may need that folder's id.
                    //
                    // Please note that not all combinations of parameters make sense and not all possible
                    // saved searches will necessarily return values, so you may not be able to create a
                    // viable saved search for all your needs with this method.
                    // We are also going to show some sample validation of some of the values, as well as
                    // some of the combinations of values, but it is entirely possible to create a valid
                    // saved search that the Search Builder tool in ProjectWise Explore will not know how
                    // to interpret and will display "Unknown criterion" in those cases.
                    //
                    // Please note that the underlying logic of PWSearch.CreateSearch() does not support
                    // the "OR Group" feature of ProjectWise Explorer's Form Builder or Search Builder.
                    ////////////////////////////////////////////////////////////////////////////////////////

                    bool bValidProperties = true;   // assume everything is valid to start...

                    ////////////////////////////////////////////////////////////////////////////////////////
                    // Below are some sample methods of converting from the more typical values you may have
                    // "on hand" to the data type that is needed, such as an Object Id instead of a name or
                    // a path.
                    // In this sample, the "on hand" values are from the .config file.
                    ////////////////////////////////////////////////////////////////////////////////////////

                    // Here's the convention I'm using for each parameter for PWSearch.CreateSearch()
                    //======================================================================================
                    // iProjectId <--- Parameter name
                    // iProjectId - aka SearchFolder <--- variable containing the value to be used
                    // Set this... <--- comments


                    //======================================================================================
                    // iProjectId - aka SearchFolder    
                    // Set this to 0 to search the entire datasource, otherwise set this to the folder id
                    // of the folder that you want to start your search from.

                    int iProjectId = 0;

                    if (!string.IsNullOrEmpty(SearchFolder))
                    {
                        iProjectId = PWWrapper.aaApi_GetProjectIdByNamePath(SearchFolder);
                        if (iProjectId == 0)
                        {
                            Console.WriteLine($"'{SearchFolder}' not found.");
                            bValidProperties = false;
                        }
                    }

                    //======================================================================================
                    // bIncludeSubVaults aka SearchSubFolders
                    // Set this to true to include any subfolders below the starting folder, otherwise
                    // false means to just search the starting folder.

                    bool bIncludeSubVaults = SearchSubFolders;

                    //======================================================================================
                    // wcFullTextString aka SearchText
                    // bWholePhrase aka WholePhase
                    // bAnyWord aka AnyWord
                    // The search string to be used for full text searches.
                    // This works in conjunction with the settings: SearchText, WholePhrase, AnyWord
                    // Note that not all combinations make logical sense, so test your results!

                    string wcFullTextString = SearchText;
                    bool bWholePhrase = WholePhrase;
                    bool bAnyWord = AnyWord;

                    //======================================================================================
                    // bSearchAttributes aka SearchAttributes
                    // arAttributesNames aka AttributeColumnNames
                    // arAttributesValues aka AttributeValues
                    // iSize you need to calculate this from the size of the arrays and the arrays must be 
                    // of the same size.

                    bool bSearchAttributes = SearchAttributes;

                    string[] arAttributeNames = null;
                    string[] arAttributeValues = null;
                    int iSize = 0;

                    if (SearchAttributes)
                    {
                        arAttributeNames = AttributeColumnNames.Split(",".ToCharArray(),
                            StringSplitOptions.RemoveEmptyEntries);
                        arAttributeValues = AttributeValues.Split(",".ToCharArray(),
                            StringSplitOptions.None);
                        iSize = arAttributeNames.Length;

                        if (arAttributeNames.Length != arAttributeValues.Length)
                        {
                            Console.WriteLine($"The attribute array sizes must match.");
                            bValidProperties = false;
                        }
                    }

                    //======================================================================================
                    // iEnvId aka EnvironmentName
                    // Set to zero if you want to search all Environments
                    int iEnvId = 0;

                    if (!string.IsNullOrEmpty(EnvironmentName))
                    {
                        iEnvId = PWWrapper.GetEnvironmentId(EnvironmentName);
                        if (iEnvId == 0)
                        {
                            Console.WriteLine($"Environment '{EnvironmentName}' not found.");
                            bValidProperties = false;
                        }
                    }

                    //======================================================================================
                    // szDocumentNameP aka DocumentName
                    // Specifying a percent sign in this value will always generate a LIKE (wildcard) search
                    // whether or not you intend it to be!

                    string szDocumentNameP = DocumentName;

                    //======================================================================================
                    // szFileNameP aka FileName
                    // Specifying a percent sign in this value will always generate a LIKE (wildcard) search
                    // whether or not you intend it to be!

                    string szFileNameP = FileName;

                    //======================================================================================
                    // szDocumentDescP aka Description
                    // Specifying a percent sign in this value will always generate a LIKE (wildcard) search
                    // whether or not you intend it to be!

                    string szDocumentDescP = Description;

                    //======================================================================================
                    // bOriginalsOnly aka OriginalsOnly
                    // Specify false if you want the search to return versions

                    bool bOriginalsOnly = OriginalsOnly;

                    //======================================================================================
                    // iWorkflowId aka Workflow
                    // Set to zero to search all workflows

                    int iWorkflowId = 0;

                    if (!string.IsNullOrEmpty(Workflow))
                    {
                        iWorkflowId = PWWrapper.GetWorkflowId(Workflow);
                        if (iWorkflowId == 0)
                        {
                            Console.WriteLine($"Workflow '{Workflow}' not found.");
                            bValidProperties = false;
                        }
                    }

                    //======================================================================================
                    // szStatesP aka States
                    // We actually need the state IDs, so we have to look these up...
                    // You can specify more than one state which is interpreted as an OR relationship but
                    // you will see "Unknown criterion" in Search Builder if you load your saved search.

                    string szStatesP = string.Empty;

                    StringBuilder sbStateIds = new StringBuilder();

                    if (States.Length > 0)
                    {
                        string[] saStates = States.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                        foreach (string sState in saStates)
                        {
                            int iStateId = PWWrapper.GetStateId(sState);

                            if (iStateId == 0)
                            {
                                Console.WriteLine($"State '{sState}' not found.");
                                bValidProperties = false;
                            }

                            if (sbStateIds.Length == 0)
                                sbStateIds.AppendFormat("{0}", iStateId);
                            else
                                sbStateIds.AppendFormat(",{0}", iStateId);
                        }
                        if (sbStateIds.Length > 0)
                            szStatesP = sbStateIds.ToString();
                    }

                    //======================================================================================
                    // szUpdatedAfterP aka UpdatedAfter
                    // dates need to be formatted to "yyyy-MM-dd HH:mm:ss"

                    string szUpdatedAfterP = string.Empty;

                    if (!string.IsNullOrEmpty(UpdatedAfter))
                    {
                        DateTime oDate = Convert.ToDateTime(UpdatedAfter);
                        if (oDate.Year > 1000)
                            szUpdatedAfterP = oDate.ToString("yyyy-MM-dd HH:mm:ss");
                    }

                    //======================================================================================
                    // szUpdatedBeforeP aka UpdatedBefore
                    // dates need to be formatted to "yyyy-MM-dd HH:mm:ss"

                    string szUpdatedBeforeP = string.Empty;

                    if (!string.IsNullOrEmpty(UpdatedBefore))
                    {
                        DateTime oDate = Convert.ToDateTime(UpdatedBefore);
                        if (oDate.Year > 1000)
                            szUpdatedBeforeP = oDate.ToString("yyyy-MM-dd HH:mm:ss");
                    }

                    //======================================================================================
                    // szSavedSearchNameP aka SearchName
                    // This approach will not support creating saved search folders, but it works for
                    // just a saved search name.
                    // See farther down for a method to support creating saved search folders.

                    string szSavedSearchNameP = SearchName;

                    if (string.IsNullOrEmpty(szSavedSearchNameP))
                    {
                        Console.WriteLine($"You must specify a name for the saved search.");
                        bValidProperties = false;
                    }

                    //======================================================================================
                    // lParentProjectId aka OwnerProject
                    // Set to 0 for a datasource global search, otherwise set to the projectId of the
                    // Parent Rich Project (Work Area)

                    int lParentProjectId = 0;

                    if (!string.IsNullOrEmpty(OwnerProject))
                    {
                        // OwnerProject must be a Rich Project (Work Area)
                        lParentProjectId = PWWrapper.aaApi_GetProjectIdByNamePath(OwnerProject);

                        int richProjectId = PWWrapper.GetRichProjectId(lParentProjectId);
                        if (richProjectId != lParentProjectId)
                        {
                            Console.WriteLine($"OwnerProject '{OwnerProject}' must be a Rich Project...");
                            bValidProperties = false;
                        }
                    }

                    //======================================================================================
                    // lParentQueryId - where to create the saved search
                    // To support creating saved search folders, we are assuming that they are part of the  
                    // specified saved search name, but are delimited by backslashes.

                    int lParentQueryId = 0;
                    string sOriginalName = SearchName;

                    string[] sSearchParts = SearchName.Split("\\".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    SearchName = sSearchParts[sSearchParts.Length - 1];

                    IntPtr hQueryBuf = PWWrapper.aaApi_SQueryDataBufferSelectAll();
                    int iQueryCount = PWWrapper.aaApi_DmsDataBufferGetCount(hQueryBuf);

                    int iSearchParentId = 0;

                    if (sSearchParts.Length > 1)
                    {
                        int iTrackSearchContainerPath = 0;

                        // must build a folder path
                        for (int j = 0; j < sSearchParts.Length - 1; j++)
                        {
                            string sSearchPart = sSearchParts[j];

                            bool bFoundSearch = false;

                            // need to check for duplicate names and project
                            for (int i = 0; i < iQueryCount; i++)
                            {
                                string sQryName = PWWrapper.aaApi_DmsDataBufferGetStringProperty(hQueryBuf, 6, i);

                                if (sQryName.ToLower() == sSearchPart.ToLower())
                                {
                                    // will be 0 for top level
                                    int iOwningProjectId = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 8, i); // 3 is owner query id

                                    // to be created in global
                                    if (lParentProjectId == 0 && iOwningProjectId == 0)
                                    {
                                        if (PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 3, i) == iTrackSearchContainerPath)
                                        {
                                            iTrackSearchContainerPath = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 1, i);
                                            bFoundSearch = true;
                                            break;
                                        }
                                    }
                                    else if (iOwningProjectId == lParentProjectId)
                                    {
                                        if (PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 3, i) == iTrackSearchContainerPath)
                                        {
                                            iTrackSearchContainerPath = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 1, i);
                                            bFoundSearch = true;
                                            break;
                                        }
                                    }
                                } // match on query name
                            } // for each existing query

                            if (!bFoundSearch)
                            {
                                Console.WriteLine($"Creating search folder '{sSearchPart}' with parent id {iTrackSearchContainerPath}");

                                // create it
                                if (PWWrapper.Is64Bit())
                                    iTrackSearchContainerPath = PWSearch.CreateSearchFolderX64(sSearchPart, lParentProjectId, iTrackSearchContainerPath);
                                else
                                    iTrackSearchContainerPath = PWSearch.CreateSearchFolder(sSearchPart, lParentProjectId, iTrackSearchContainerPath);
                            }

                        } // for each piece of the path

                        iSearchParentId = iTrackSearchContainerPath;

                    } // has a parent folder path

                    // WriteVerbose(string.Format("Search Parent Id {0}", iSearchParentId));

                    // check the search name

                    int iExistingSearchId = 0;

                    // need to check for duplicate names and project
                    for (int i = 0; i < iQueryCount; i++)
                    {
                        string sQryName = PWWrapper.aaApi_DmsDataBufferGetStringProperty(hQueryBuf, 6, i);

                        if (sQryName.ToLower() == SearchName.ToLower())
                        {
                            // will be 0 for top level
                            int iOwningProjectId = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 8, i); // 3 is owner query id

                            // to be created in global
                            if (lParentProjectId == 0 && iOwningProjectId == 0)
                            {
                                if (PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 3, i) == iSearchParentId)
                                {
                                    iExistingSearchId = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 1, i);
                                    break;
                                }
                            }
                            else if (iOwningProjectId == lParentProjectId)
                            {
                                if (PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 3, i) == iSearchParentId)
                                {
                                    iExistingSearchId = PWWrapper.aaApi_DmsDataBufferGetNumericProperty(hQueryBuf, 1, i);
                                    break;
                                }
                            }
                        }
                    } // for each existing query

                    PWWrapper.aaApi_DmsDataBufferFree(hQueryBuf);

                    if (iExistingSearchId > 0)
                    {
                        if (ReplaceExisting)
                            PWSearch.aaApi_SQueryDelete(iExistingSearchId);
                        else
                        {
                            Console.WriteLine($"Search '{sOriginalName}' already exists. Change value of ReplaceExisting to 'true' to enable replacement.");
                            bValidProperties = false;
                        }
                    }

                    szSavedSearchNameP = SearchName;
                    lParentQueryId = iSearchParentId;

                    //======================================================================================
                    // szViewName aka ViewName
                    // Ignored if not valid
                    // Uses Personal view if ViewName exists in both Global and Personal
                    // But CreateSearch() only creates Global saved searches

                    string szViewName = ViewName;

                    ////////////////////////////////////////////////////////////////////////////////////////
                    // Try to create a new saved search if we think all the parameters are OK...
                    // Parameter names below match what has been exported from PWSearchWrapper.dll to help
                    // guide you since there are over 20 parameters!  Obviously, you can name your variables
                    // anything you want to!
                    ////////////////////////////////////////////////////////////////////////////////////////

                    int createdSaveSearchId = 0;

                    if (bValidProperties)
                    {
                        ////////////////////////////////////////////////////////////////////////////////////////
                        // NOTES:
                        // PWSearch.CreateSearch() is NOT a full implementation of the features found in either
                        // "Search Form" or "Search Builder" available in ProjectWise Explorer. You can create
                        // save searches using those client tools, or with CreateSearch() to create saved
                        // searches that will never select any documents because the constraints are not
                        // such that there are never any documents that will meet the constraints.
                        // However, the tools provided in ProjectWise Explorer limit your choices to much more
                        // reasonable criteria, while CreateSearch() used by this sample ASSUMES that you, as the 
                        // caller, are passing reasonable combinations of parameters.  For example, you cannot
                        // select both "AnyWord" and "WholePhrase" using ProjectWise Explorer, but you can 
                        // specify both in your call to CreateSearch(), but only documents meeting both the
                        // AnyWord and the WholePhrase constraint will be returned by your search, which
                        // effectively is just the ones meeting the WholePhrase constraint!
                        // Also, it is possible to creates search criteria using CreateSearch() that is valid
                        // (and works!), but "Search Form" and "Search Builder" don't know how to interpret
                        // the saved criteria if you load your search into either. In those cases, you will
                        // see "Unknown criterion" listed in the search dialog.
                        // Please also note that CreateSearch() does not support the "OR Group" feature found
                        // in the tools in ProjectWise Explorer.  You can implement all those features as well
                        // as any of your own "features" yourself using the native ProjectWise SDK APIs.
                        // Unfortunately, creating saved searches is a relatively complex and tedious task
                        // as well as requiring you, the developer, to understanding what combinations of
                        // search criteria are valid.
                        ////////////////////////////////////////////////////////////////////////////////////////

                        if (PWWrapper.Is64Bit())
                        {
                            createdSaveSearchId = PWSearch.CreateSearchX64(
                                iProjectId,         // 0 = Datasource Global or id for Rich Project Global
                                bIncludeSubVaults,
                                wcFullTextString,   // for full text search
                                bWholePhrase,       // for matching the full text string
                                bAnyWord,           // otherwise match any of the words in the full text string
                                bSearchAttributes,  // if false, saAttribute* must be null and a full text search is created
                                szDocumentNameP,    // can include % for LIKE searches
                                szFileNameP,        // can include % for LIKE searches
                                szDocumentDescP,    // can include % for LIKE searches
                                bOriginalsOnly,     // false means return matching versions as well as the active document (original)
                                iEnvId,             // 0 = search all environments
                                arAttributeNames,   // string array of DATABASE COLUMN names to search
                                arAttributeValues,  // matching string array of values to search for, can include % for LIKE searches
                                iSize,              // size of the arrays (both must be of the same size)
                                iWorkflowId,        // 0 = search all workflows
                                szStatesP,          // stateIds separated by commas, not the state names
                                szUpdatedAfterP,    // string value formatted "yyyy-MM-dd HH:mm:ss"
                                szUpdatedBeforeP,   // string value formatted "yyyy-MM-dd HH:mm:ss"
                                szSavedSearchNameP, // Just the actual search name, not any saved search folders...
                                lParentProjectId,   // 0 for global searches, otherwise the id of the search folder
                                lParentQueryId,
                                szViewName);
                        }
                        else
                        {
                            createdSaveSearchId = PWSearch.CreateSearch(
                                iProjectId,         // 0 = Datasource Global or id for Rich Project Global
                                bIncludeSubVaults,
                                wcFullTextString,   // for full text search
                                bWholePhrase,       // for matching the full text string
                                bAnyWord,           // otherwise match any of the words in the full text string
                                bSearchAttributes,  // if false, saAttribute* must be null and a full text search is created
                                szDocumentNameP,    // can include % for LIKE searches
                                szFileNameP,        // can include % for LIKE searches
                                szDocumentDescP,    // can include % for LIKE searches
                                bOriginalsOnly,     // false means return matching versions as well as the active document (original)
                                iEnvId,
                                arAttributeNames,   // string array of DATABASE COLUMN names to search
                                arAttributeValues,  // matching string array of values to search for, can include % for LIKE searches
                                iSize,              // size of the arrays (both must be of the same size)
                                iWorkflowId,        // 0 = search all workflows
                                szStatesP,          // stateIds separated by commas, not the state names
                                szUpdatedAfterP,    // string value formatted "yyyy-MM-dd HH:mm:ss"
                                szUpdatedBeforeP,   // string value formatted "yyyy-MM-dd HH:mm:ss"
                                szSavedSearchNameP, // can include saved search folders separated by backslash character "\"
                                lParentProjectId,   // 0 for global searches, Rich Project ID for Work Area Global Searches
                                lParentQueryId,
                                szViewName);
                        }

                        if (createdSaveSearchId == 0)
                        {
                            Console.WriteLine($"No search created.");
                        }
                        else
                        {
                            Console.WriteLine($"Search '{SearchName}' was created with an id of '{createdSaveSearchId}'.");
                            Console.WriteLine("Note that it is possible to create save searches with invalid criteria!");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"At least one search property was invalid, no search created.");
                    }

                    // A good practice is to Logout and uninitialize the ProjectWise APIs
                    if (!PWWrapper.aaApi_LogoutByHandle(PWWrapper.aaApi_GetActiveDatasource()))
                    {
                        ShowPWError();
                        ExitApp(-5);    // arbitrary exit code
                    }
                    else
                    {
                        Console.WriteLine("Logged out.");
                        PWWrapper.aaApi_Uninitialize(); // good practice
                        ExitApp(0); // indicates success!
                    }
                }
            }
            catch (Exception ex)
            {
                // using the Exception message
                Console.WriteLine(ex.Message);

                // optionally
                Console.WriteLine("StackTrace: {0}", ex.StackTrace);

                // no point in continuing 
                ExitApp(-3);    // arbitrary exit code
            }
        }
    }
}
